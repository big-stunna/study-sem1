/*
  Week 10 - Activity: Capstone

  Learning objectives:
  - Calculate the rate of change of the error between loops
  - Use the D term to damp the overshoot caused by the P term alone

  Instructions:
  - Paste readError(), moveForward(leftSpeed, rightSpeed) and stopMotors() as in Activity 2
  - Set Kp to the value you chose in Section 2.4
  - Fill the blanks " _______ " -> " with something as instructed "
*/

////////////////////////////////////////////////////////////////////////////////
                              //CODE STARTS


// ================= LIBRARIES =================
#include <IRArray.h>
#include <Wire.h>
#include <Adafruit_PCF8574.h>
#include <Adafruit_NeoPixel.h>


// ================= PIN DEFINITIONS =================
#define TRIG_PIN  3     // HC-SR04 Trig — Arduino pin D3
#define ECHO_PIN  2     // HC-SR04 Echo — Arduino pin D2
#define NUM_LEDS 4      // Number of LED's on AlphaBot2
#define LED_PIN 7       // data pin for the LED chain on AlphaBot2
#define AIN1   A0
#define AIN2   A1
#define PWMA   6
#define BIN1   A3
#define BIN2   A2
#define PWMB   5
#define BUZZER_PIN  5    // buzzer on PCF8574 pin 5


// ================= CONSTANTS =================
#define THRESHOLD    969
#define BASE_SPEED   55
#define MAX_SPEED    120
#define OBSTACLE_DISTANCE  25   // Distance (cm) to register obstacle ahead


// ================= TUNING =================
float Kp = 25.0;     // TODO: your own value from Section 2.4
float Kd = 395.0;       // derivative gain, start here, tune it below
                        // play with Kd values in the range 300 to 1000

// ================= OBJECTS =================
IRArray ir;
unsigned int sensorValues[5];
Adafruit_PCF8574 pcf;
Adafruit_NeoPixel RGB = Adafruit_NeoPixel(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);


// ================= VARIABLES =================
int   weights[5] = { 2, 1, 0, -1, -2 }; 
float lastKnownError = 0;      // used inside readError() when the line is lost
float previousError  = 0;      // the error from the previous loop, used by the D term


// ================= MOVEMENT FUNCTIONS =================
// Paste moveForward(leftSpeed, rightSpeed) and stopMotors() from Week 5, Section A.3, here.
void moveForward(int leftSpeed, int rightSpeed) {
  // left motor forward: AIN1 HIGH, AIN2 LOW
  digitalWrite(AIN1, HIGH);
  digitalWrite(AIN2, LOW);
  analogWrite(PWMA, leftSpeed);   // FIXED: uses calculated leftSpeed parameter

  // right motor forward: BIN1 HIGH, BIN2 LOW
  digitalWrite(BIN1, HIGH);
  digitalWrite(BIN2, LOW);
  analogWrite(PWMB, rightSpeed);  // FIXED: uses calculated rightSpeed parameter
}

void stopMotors() {
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, LOW);
  analogWrite(PWMA, 0);

  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, LOW);
  analogWrite(PWMB, 0);
}

// ================= SENSORS & BUZZER =================
long readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 25000); // 25ms timeout
  if (duration == 0) return 100;                  // No reflection detected
  return duration / 58;
}


void beepBuzzer(int times) {
  for (int i = 0; i < times; i++) {
    pcf.digitalWrite(BUZZER_PIN, LOW);   // Buzzer ON
    delay(200);
    pcf.digitalWrite(BUZZER_PIN, HIGH);  // Buzzer OFF
    delay(150);
  }
}

// LED display for IR1, IR2, IR4, IR5: Green = Black Line, Red = White Line
void updateSensorLEDs() {
  int displayIndices[4] = {0, 1, 3, 4}; // Skip IR3 (center)
  for (int i = 0; i < 4; i++) {
    int sensorIdx = displayIndices[i];
    if (sensorValues[sensorIdx] > THRESHOLD) {
      RGB.setPixelColor(i, RGB.Color(255, 0, 0)); // White line
    } else {
      RGB.setPixelColor(i, RGB.Color(0, 255, 0)); // Black surface
    }
  }
  RGB.show();
}





// ================= ERROR FUNCTION =================
// Paste readError() from Section 1.4 here.
// ================= ERROR FUNCTION =================
// What this function does, step by step:
//   1. Read all 5 sensors.
//   2. Go through each sensor one at a time.
//   3. If that sensor sees black (it is over the line), remember its weight,
//      and count it as "one more sensor on the line".
//   4. Once all 5 sensors are checked, average the weights we collected.
//      That average is the error.
// ================= ERROR FUNCTION =================
// What this function does, step by step:
//   1. Read all 5 sensors.
//   2. Go through each sensor one at a time.
//   3. If that sensor sees white (it is over the line), remember its weight,
//      and count it as "one more sensor on the line".
//   4. Once all 5 sensors are checked, average the weights we collected.
//      That average is the error.

// +++++++++++++++++++++READ ERROR FUNCTION ACCORDING TO THE WHITE LINE ON BLACK SURFACE+++++++++++++++++++++++++++++++++++++++

float readError() {

  ir.read(sensorValues);   // fills sensorValues[0] to sensorValues[4] with fresh readings

  int   whiteCount  = 0;   // how many sensors currently see white, starts at 0
  float weightedSum = 0;   // running total of weights, only from sensors that see white

  // Look at each of the 5 sensors in turn, one after another.
  for (int i = 0; i < 5; i++) {

    if (sensorValues[i] > THRESHOLD) {  // CHANGED: '>' detects white line

      weightedSum = weightedSum + weights[i];   // add this sensor's weight to the running total
      whiteCount  = whiteCount + 1;             // found one more sensor on the white line

    }
    // if the sensor is on black (not on the line), do nothing and continue
  }

  // After checking all 5 sensors, whiteCount tells us how many saw white.

  if (whiteCount == 0) {
    // No sensor saw the white line at all. Return the last valid error.
    return lastKnownError;
  }

  // At least one sensor saw the white line. Calculate the average.
  lastKnownError = weightedSum / whiteCount;
  return lastKnownError;
}








// ================= SETUP =================
void setup() {

 pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  pinMode(PWMA, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);

  // Ultrasonic sensor pins
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Initialize PCF8574 Buzzer
  pcf.begin(0x20, &Wire);
  pcf.pinMode(BUZZER_PIN, OUTPUT);
  pcf.digitalWrite(BUZZER_PIN, HIGH); // buzzer OFF

  // Initialize NeoPixels
  RGB.begin();
  RGB.show();

  ir.begin();

  stopMotors();

  // Start delay: gives time to place the robot in START and step away
  delay(4000);
}


// ================= LOOP =================
void loop() {

  float error = readError();
  // 1. Update LEDs
  updateSensorLEDs();

  // 2. Count White Sensors
  int whiteCount = 0;
  for (int i = 0; i < 5; i++) {
    if (sensorValues[i] > THRESHOLD) {
      whiteCount++;
    }
  }

  // 3. END Zone Check: All 5 sensors see white
  if (whiteCount == 5) {
    stopMotors();
    for (int i = 0; i < 4; i++) {
      RGB.setPixelColor(i, RGB.Color(255, 0, 0));
    }
    RGB.show();
    beepBuzzer(3);
    while (1) {
      stopMotors();
    }
  }

  // 4. Junction Check: 3 or more sensors see white
  if (whiteCount >= 3) {
  long distance = readDistance();
  if (distance <= OBSTACLE_DISTANCE) {
    // Obstacle ahead -> Take the branch
    // IR1 (sensorValues[0]) and IR2 (sensorValues[1]) are on the LEFT
    if (sensorValues[0] > THRESHOLD || sensorValues[1] > THRESHOLD) {
      moveForward(0, BASE_SPEED);   // Turn left onto branch
    } 
    else {
      moveForward(BASE_SPEED, 0);   // Turn right onto branch
    }
    delay(550);
    return;
  }
}


  float derivative = error - previousError;                          // TODO: compare against the previous loop's error

  float correction = (Kp * error) + (Kd * derivative);    // TODO: scale the derivative by its own gain
  
  int leftSpeed  = BASE_SPEED - correction;
  int rightSpeed = BASE_SPEED + correction;   // opposite adjustment on the other wheel
  
  leftSpeed  = constrain(leftSpeed,  0, MAX_SPEED);
  rightSpeed = constrain(rightSpeed,  0, MAX_SPEED);

  moveForward(leftSpeed, rightSpeed);

  previousError = error;                                             // TODO: save this loop's error for the next loop
}
