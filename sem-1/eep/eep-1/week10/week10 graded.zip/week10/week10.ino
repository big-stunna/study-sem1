/*
  Week 10 Capstone: Obstacle Avoiding Line Follower (AlphaBot2)
  - Start delay, then follow the white line with PD control
  - Junction (3+ sensors white): obstacle ahead -> take branch, clear -> go straight
  - LEDs show IR1, IR2, IR4, IR5: red = white, green = black
  - END (all 5 white): stop, beep 3 times
*/

////////////////////////////////////////////////////////////////////////////////
                              //CODE STARTS


// ================= LIBRARIES =================
// #include loads ready-made code so we can use its functions.
#include <IRArray.h>            // ir.begin(), ir.read(): reads the 5 IR line sensors via the TLC1543 ADC chip
#include <Wire.h>               // Arduino I2C library (2 wires: SDA = A4, SCL = A5); PCF8574 talks over it
#include <Adafruit_PCF8574.h>   // controls the PCF8574 I/O expander (extra pins); the buzzer is on it
#include <Adafruit_NeoPixel.h>  // controls the 4 WS2812B RGB LEDs


// ================= PIN DEFINITIONS =================
// #define NAME value: the compiler replaces NAME with value everywhere (uses no memory).
#define TRIG_PIN  3     // ultrasonic Trig (D3): a HIGH pulse here makes it send a sound burst
#define ECHO_PIN  2     // ultrasonic Echo (D2): goes HIGH for as long as the echo takes to return
#define NUM_LEDS 4      // the AlphaBot2 has 4 RGB LEDs
#define LED_PIN 7       // D7: one data wire drives all 4 LEDs (they are chained)
#define AIN1   A0       // left motor direction pin 1 (with AIN2 sets forward/reverse/stop)
#define AIN2   A1       // left motor direction pin 2
#define PWMA   6        // left motor speed: PWM pin, analogWrite 0-255
#define BIN1   A3       // right motor direction pin 1
#define BIN2   A2       // right motor direction pin 2
#define PWMB   5        // right motor speed: PWM pin, analogWrite 0-255
#define BUZZER_PIN  5   // pin P5 on the PCF8574 chip (NOT Arduino pin 5)


// ================= CONSTANTS =================
#define THRESHOLD    959        // IR reading (0-1023) above this = white line, below = black track
#define BASE_SPEED   65         // speed of both wheels when the line is centred (0-255)
#define MAX_SPEED    120        // no wheel may go faster than this, even while steering
#define OBSTACLE_DISTANCE  25   // at a junction, an object this close (cm) or closer = road blocked


// ================= TUNING =================
// float = number with decimals.
float Kp = 24.0;    // P gain: correction grows with how far the line is from the centre
float Kd = 371.0;   // D gain: correction grows with how fast that distance is changing -> damps wobble


// ================= OBJECTS =================
IRArray ir;                       // object used to talk to the line sensors
unsigned int sensorValues[5];     // array of 5 readings (0-1023): [0] = IR1 (right) ... [4] = IR5 (left)
Adafruit_PCF8574 pcf;             // object used to talk to the PCF8574 (buzzer chip)
Adafruit_NeoPixel RGB = Adafruit_NeoPixel(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);   // 4 LEDs on pin 7; GRB colour order, 800 kHz signal


// ================= VARIABLES =================
int   weights[5] = { 2, 1, 0, -1, -2 };   // position score per sensor: IR1 = +2 ... IR3 = 0 (centre) ... IR5 = -2
float lastKnownError = 0;   // error from the last time the line was seen; used when the line is lost
float previousError  = 0;   // error from the previous loop; needed to work out the D term


// ================= MOVEMENT FUNCTIONS =================
// Drives both wheels forward, each at its own speed (0-255).
// Equal speeds = straight; unequal = robot turns toward the slower wheel.
void moveForward(int leftSpeed, int rightSpeed) {
  digitalWrite(AIN1, HIGH);        // left motor: AIN1 HIGH +
  digitalWrite(AIN2, LOW);         //             AIN2 LOW  = spin forward
  analogWrite(PWMA, leftSpeed);    // left motor speed via PWM

  digitalWrite(BIN1, HIGH);        // right motor: BIN1 HIGH +
  digitalWrite(BIN2, LOW);         //              BIN2 LOW  = spin forward
  analogWrite(PWMB, rightSpeed);   // right motor speed via PWM
}

// Stops both wheels.
void stopMotors() {
  digitalWrite(AIN1, LOW);         // left: both direction pins LOW = coast (no drive)
  digitalWrite(AIN2, LOW);
  analogWrite(PWMA, 0);            // left speed 0

  digitalWrite(BIN1, LOW);         // right: both direction pins LOW = coast
  digitalWrite(BIN2, LOW);
  analogWrite(PWMB, 0);            // right speed 0
}


// ================= SENSORS & BUZZER =================
// Returns the distance to whatever is ahead, in cm. long = big whole number.
long readDistance() {
  digitalWrite(TRIG_PIN, LOW);     // make sure Trig starts LOW
  delayMicroseconds(2);            // wait 2 us so the line is settled
  digitalWrite(TRIG_PIN, HIGH);    // Trig HIGH...
  delayMicroseconds(10);           // ...for 10 us -> sensor sends an ultrasonic burst
  digitalWrite(TRIG_PIN, LOW);     // end of trigger pulse

  long duration = pulseIn(ECHO_PIN, HIGH, 25000);   // measure how long Echo stays HIGH (us); 0 if nothing within 25 ms
  if (duration == 0) return 100;                    // no echo came back -> nothing ahead, report 100 cm (clear)
  return duration / 58;                             // us -> cm: sound ~0.0343 cm/us, there and back -> /58
}

// Beeps the buzzer 'times' times. Buzzer is active LOW: LOW = ON, HIGH = OFF.
void beepBuzzer(int times) {
  for (int i = 0; i < times; i++) {       // repeat 'times' times
    pcf.digitalWrite(BUZZER_PIN, LOW);    // tell the PCF8574 (over I2C) to set P5 LOW -> buzzer ON
    delay(200);                           // beep for 0.2 s
    pcf.digitalWrite(BUZZER_PIN, HIGH);   // P5 HIGH -> buzzer OFF
    delay(150);                           // 0.15 s gap before the next beep
  }
}

// Shows sensors IR1, IR2, IR4, IR5 on LEDs 0-3 (IR3 has no LED; only 4 LEDs).
void updateSensorLEDs() {
  int displayIndices[4] = {0, 1, 3, 4};   // LED 0 -> IR1, LED 1 -> IR2, LED 2 -> IR4, LED 3 -> IR5
  for (int i = 0; i < 4; i++) {           // go through the 4 LEDs
    int sensorIdx = displayIndices[i];    // which sensor this LED shows
    if (sensorValues[sensorIdx] > THRESHOLD) {
      RGB.setPixelColor(i, RGB.Color(255, 0, 0));   // sensor on white -> LED red (R=255, G=0, B=0)
    } else {
      RGB.setPixelColor(i, RGB.Color(0, 255, 0));   // sensor on black -> LED green
    }
  }
  RGB.show();   // send the colours to the LEDs; nothing changes until show() is called
}


// ================= ERROR FUNCTION =================
// Error = how far the white line is from the robot's centre.
// = average weight of the sensors that see white (0 = centred, + / - = which side).
// If no sensor sees white, the line is lost: return the last error so the
// robot keeps turning the same way until it finds the line again.
float readError() {

  ir.read(sensorValues);   // read all 5 sensors into sensorValues[0..4]

  int   whiteCount  = 0;   // how many sensors see white; start at 0
  float weightedSum = 0;   // total of the weights of those sensors; start at 0

  for (int i = 0; i < 5; i++) {                 // check sensors 0..4 one by one
    if (sensorValues[i] > THRESHOLD) {          // high reading = this sensor is on the white line
      weightedSum = weightedSum + weights[i];   // add its position score
      whiteCount  = whiteCount + 1;             // count one more sensor on the line
    }
  }

  if (whiteCount == 0) {   // no sensor sees the line (all black) -> line lost
    return lastKnownError; // reuse the last good error
  }

  lastKnownError = weightedSum / whiteCount;   // average of the weights = error; store it as the new "last good"
  return lastKnownError;                       // give the error back to loop()
}


// ================= SETUP =================
// Runs once when the robot is switched on.
void setup() {

  pinMode(AIN1, OUTPUT);   // all 6 motor pins are outputs (Arduino controls them)
  pinMode(AIN2, OUTPUT);
  pinMode(PWMA, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);

  pinMode(TRIG_PIN, OUTPUT);   // Trig: Arduino sends the pulse -> output
  pinMode(ECHO_PIN, INPUT);    // Echo: Arduino listens -> input

  pcf.begin(0x20, &Wire);               // start talking to the PCF8574 at I2C address 0x20
  pcf.pinMode(BUZZER_PIN, OUTPUT);      // make its P5 an output (to drive the buzzer)
  pcf.digitalWrite(BUZZER_PIN, HIGH);   // HIGH = buzzer OFF (active LOW)

  RGB.begin();   // start the LED strip
  RGB.show();    // send "all off" so the LEDs start dark

  ir.begin();    // start the IR line sensors

  stopMotors();  // make sure the wheels are still

  delay(4000);   // start delay (4 s): place robot in START, step out of view, start recording
}


// ================= LOOP =================
// Repeats forever, many times per second: sense -> decide -> drive.
void loop() {

  // 1. SENSE: where is the line?
  float error = readError();   // reads the sensors and returns the error

  // 2. Show the sensors on the LEDs
  updateSensorLEDs();

  // 3. Count how many sensors see white
  int whiteCount = 0;                     // start the count at 0
  for (int i = 0; i < 5; i++) {           // check all 5 sensors
    if (sensorValues[i] > THRESHOLD) {    // this one sees white
      whiteCount++;                       // ++ adds 1
    }
  }

  // 4. END box: all 5 sensors see white
  if (whiteCount == 5) {
    stopMotors();                                    // stop the wheels
    for (int i = 0; i < 4; i++) {
      RGB.setPixelColor(i, RGB.Color(255, 0, 0));    // set all 4 LEDs red
    }
    RGB.show();                                      // apply the colours
    beepBuzzer(3);                                   // beep 3 times: load delivered
    while (1) {        // infinite loop: the program stays here forever...
      stopMotors();    // ...keeping the motors off, so the robot never moves again
    }
  }

  // 5. Junction: 3 or more sensors white (the white area widens where a branch splits off)
  if (whiteCount >= 3) {
    long distance = readDistance();          // measure the distance ahead with the ultrasonic
    if (distance <= OBSTACLE_DISTANCE) {     // obstacle within 25 cm -> road blocked -> take the branch
      // || means OR: if IR1 or IR2 sees white, the branch is on that side
      if (sensorValues[0] > THRESHOLD || sensorValues[1] > THRESHOLD) {
        moveForward(0, BASE_SPEED);          // left wheel stopped, right wheel driving -> robot pivots
      }
      else {                                 // otherwise the branch is on the other side
        moveForward(BASE_SPEED, 0);          // right wheel stopped, left wheel driving -> pivots the other way
      }
      delay(550);                            // keep pivoting for 0.55 s (timed, sensors not checked)
      return;                                // end this loop() pass early; loop() restarts from the top
    }
    // no obstacle -> nothing special; code continues to PD below, which follows the main line straight
  }

  // 6. PD steering: correction = Kp*error + Kd*(error - previousError)
  float derivative = error - previousError;              // change in error since last loop (how fast we drift)
  float correction = (Kp * error) + (Kd * derivative);   // P part (how far off) + D part (how fast) = how much to steer

  int leftSpeed  = BASE_SPEED - correction;   // one wheel slows down...
  int rightSpeed = BASE_SPEED + correction;   // ...the other speeds up -> robot turns back toward the line

  leftSpeed  = constrain(leftSpeed,  0, MAX_SPEED);   // keep left speed between 0 and MAX_SPEED
  rightSpeed = constrain(rightSpeed, 0, MAX_SPEED);   // same for right (no negative or too-fast values)

  moveForward(leftSpeed, rightSpeed);   // drive with the new speeds

  previousError = error;   // save this error; the next loop needs it for the D term
}
