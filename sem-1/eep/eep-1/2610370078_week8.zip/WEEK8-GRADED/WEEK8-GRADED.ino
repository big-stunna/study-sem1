/*
  Week 8 - Graded Activity: AlphaBot2 Oval Track Challenge

  Same code as Activity 2 (Section 2.3), Bang-Bang Line Following.
  Only FOLLOW_SPEED and TURN_SPEED updated to the values tuned in Section 3.
*/

////////////////////////////////////////////////////////////////////////////////
                              //CODE STARTS


// ================= LIBRARIES =================
#include <IRArray.h>

// ================= PIN DEFINITIONS =================
// Left motor channel - Motor A
#define AIN1   A1    // left motor direction pin 1
#define AIN2   A0    // left motor direction pin 2
#define PWMA   6     // left motor speed - PWM pin (~)

// Right motor channel - Motor B
#define BIN1   A2    // right motor direction pin 1
#define BIN2   A3    // right motor direction pin 2
#define PWMB   5     // right motor speed - PWM pin (~)

// ================= CONSTANTS =================
#define THRESHOLD      960    // use your calibrated value from Week 7, Section 7
#define FOLLOW_SPEED   70     // PWM - speed while driving straight
#define TURN_SPEED     90     // PWM - speed while correcting

// ================= OBJECTS =================
IRArray ir;
unsigned int sensorValues[5];


// ================= MOVEMENT FUNCTIONS =================
void moveForward(int speed) {
  // both motors forward
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, HIGH);
  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, HIGH);
  analogWrite(PWMA, speed);
  analogWrite(PWMB, speed);
}

void turnLeft(int speed) {
  // pivot left: left wheel coasts, right wheel drives forward
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, LOW);
  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, HIGH);
  analogWrite(PWMA, 0);
  analogWrite(PWMB, speed);
}

void turnRight(int speed) {
  // pivot right: right wheel coasts, left wheel drives forward
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, HIGH);
  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, LOW);
  analogWrite(PWMA, speed);
  analogWrite(PWMB, 0);
}

void stopMotors() {
  // both motors coast: all direction pins LOW, speed 0
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, LOW);
  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, LOW);
  analogWrite(PWMA, 0);
  analogWrite(PWMB, 0);
}


// ================= SETUP =================
void setup() {
  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  pinMode(PWMA, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  stopMotors();

  ir.begin();
}


// ================= LOOP =================
void loop() {
  ir.read(sensorValues);

  bool leftBlack  = sensorValues[4] < THRESHOLD;    // IR5, leftmost sensor
  bool rightBlack = sensorValues[0] < THRESHOLD;    // IR1, rightmost sensor

  if (leftBlack == true) {           // line has drifted left
    turnLeft(TURN_SPEED);
  } else if (rightBlack == true) {   // line has drifted right
    turnRight(TURN_SPEED);
  } else {
    moveForward(FOLLOW_SPEED);       // centred - drive straight
  }
}
