/*
  Week 6 - Graded Activity: Non-Blocking Robot Movement
*/

#include <Wire.h>
#include <Adafruit_PCF8574.h>
#include <Adafruit_NeoPixel.h>

// ================= CONSTANTS =================
#define AIN1   A1
#define AIN2   A0
#define PWMA   6
#define BIN1   A2
#define BIN2   A3
#define PWMB   5

#define PIN         7
#define BUZZER_PIN  5

// ================= OBJECTS =================
Adafruit_PCF8574 pcf;
Adafruit_NeoPixel RGB = Adafruit_NeoPixel(4, PIN, NEO_GRB + NEO_KHZ800);

// ================= TIMERS =================
unsigned long lastBlinkTime = 0;
unsigned long lastBeepTime = 0;

const unsigned long blinkInterval = 500;
const unsigned long beepInterval = 1500;

bool ledState = false;
bool buzzerState = false;


// ================= MOVEMENT FUNCTION =================
void circleArc(int leftSpeed, int rightSpeed) {

  // Left motor
  digitalWrite(AIN1, HIGH);
  digitalWrite(AIN2, LOW);
  analogWrite(PWMA, leftSpeed);

  // Right motor
  digitalWrite(BIN1, HIGH);
  digitalWrite(BIN2, LOW);
  analogWrite(PWMB, rightSpeed);
}


// ================= SETUP =================
void setup() {

  pcf.begin(0x20, &Wire);

  pcf.pinMode(BUZZER_PIN, OUTPUT);
  pcf.digitalWrite(BUZZER_PIN, HIGH);

  RGB.begin();
  RGB.show();

  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  pinMode(PWMA, OUTPUT);

  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);
}


// ================= LOOP =================
void loop() {

  // Robot continuously moves in a circle
  circleArc(60, 90);

  // ================= RGB LED TIMER =================
  if (millis() - lastBlinkTime >= blinkInterval) {

    lastBlinkTime = millis();
    ledState = !ledState;

    if (ledState) {
      for (int i = 0; i < 4; i++) {
        RGB.setPixelColor(i, RGB.Color(0, 0, 255));
      }
    } 
    else {
      for (int i = 0; i < 4; i++) {
        RGB.setPixelColor(i, RGB.Color(0, 0, 0));
      }
    }

    RGB.show();
  }


  // ================= BUZZER TIMER =================
  if (millis() - lastBeepTime >= beepInterval) {

    lastBeepTime = millis();
    buzzerState = !buzzerState;

    if (buzzerState) {
      pcf.digitalWrite(BUZZER_PIN, LOW);   // ON
    } 
    else {
      pcf.digitalWrite(BUZZER_PIN, HIGH);  // OFF
    }
  }
}